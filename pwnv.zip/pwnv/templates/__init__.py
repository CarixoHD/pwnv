from pwnv.templates.pwn_template import template as pwn_template

__all__ = ["pwn_template"]
